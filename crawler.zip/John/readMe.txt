Crawler: 

---requirement: 
Scrapy 



----How to run crawler-------
1. Go to John file in command line (C:\Py\finaltest\John)

2. Type "Scrapy crawl John" into command windows （C:\Py\finaltest\John> scrapy crawl John）

3. get result 

4. output as Json  (C:\Py\finaltest\John> scrapy crawl John -o result.json)