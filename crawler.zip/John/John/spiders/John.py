from scrapy.spiders import CrawlSpider, Rule
from scrapy.linkextractors import LinkExtractor



class finaltest(CrawlSpider):
    name = "John"
    allowed_domains =["monergism.com"]

    start_urls=["https://www.monergism.com/900-free-ebooks-listed-alphabetically-author"]

    rules = (
        Rule(LinkExtractor(allow=r"-ebook"), callback="parse_item"),
    )

# response.xpath('//a[contains(@href, "ebook")]/@href')
    def parse_item(self, response):
        yield{
            "URL": response.xpath("/html/head/link[2]/@href").extract(),
            "Title": response.css("h1::text").get(),
            "Author": response.css("h3::text").get(),
            "Content": response.css("div.field-items p::text").getall()
        }
